/* ScummVM - Graphic Adventure Engine
 *
 * ScummVM is the legal property of its developers, whose names
 * are too numerous to list here. Please refer to the COPYRIGHT
 * file distributed with this source distribution.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef DEVOPTAB_FILESYSTEM_FACTORY_H
#define DEVOPTAB_FILESYSTEM_FACTORY_H

#include "backends/fs/posix-drives/posix-drives-fs-factory.h"

/**
 * A FilesystemFactory implementation for filesystems with a special
 * top-level directory listing all registered devoptab devices but
 * that otherwise implement the POSIX APIs.
 */
class DevoptabFilesystemFactory final : public DrivesPOSIXFilesystemFactory {
public:
	DevoptabFilesystemFactory();
};

#endif
