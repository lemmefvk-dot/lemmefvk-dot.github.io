#!/bin/sh
# AetherOS 3.0 — dev server. ES modules need http://, not file://
#
# While it runs, build.json and offline.json are re-stamped every 2 s (what
# ./watch.sh does). The offline copy (sw.js) serves a build's files from its
# own cache until build.json changes, so a stale build.json — say, one left
# behind by ./deploy.sh — would keep showing old code after an edit. The
# downloadable copy has no tools/ and keeps the build.json it shipped with.
PORT="${1:-8000}"
cd "$(dirname "$0")" || exit 1
if [ -f tools/bump.mjs ] && command -v node >/dev/null 2>&1; then
  node tools/bump.mjs --quiet
  ( while :; do sleep 2; node tools/bump.mjs --quiet >/dev/null 2>&1; done ) &
  STAMPER=$!
  trap 'kill "$STAMPER" 2>/dev/null' EXIT INT TERM
fi
echo "AetherOS 3.0 → http://localhost:$PORT"
python3 -m http.server "$PORT" --bind 127.0.0.1
